class a
{
void display()
{
System.out.println("a class");
}
}
class b extends a
{

}
class c extends a
{

}

class Multilevel
{
public static void main(String arg[])
{c C=new c();
C.display();

}
}