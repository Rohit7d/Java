import java.util.*;
class Fact
{
int fact(int n)
{
if(n==0|n==1)
return 1;
else
return n*fact(n-1);
}
}
class Factorial
{
public static void main(String arg[])
{
Scanner s=new Scanner(System.in);
System.out.println("ENTER ANY NUMBER");
int n=s.nextInt();
Fact f=new Fact();
int r=f.fact(n);
System.out.println(r);
}
}