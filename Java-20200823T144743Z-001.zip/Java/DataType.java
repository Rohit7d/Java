class DataType
{
public static void main(String arg[])
{
int a=77;
byte b=123;
short s=12;
float f=123.56f;
long l=123456789;
double d=123456;
boolean x=true,y=false;
char c='k';
System.out.println(a);
System.out.println(b);
System.out.println(s);
System.out.println(f);
System.out.println(l);
System.out.println(d);
System.out.println(x);
System.out.println(y);
System.out.println(c);
}
}
