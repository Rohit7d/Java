class Print1
{
public static void main(String arg[])
{ 
int i,r,a=50000,count=0;
for(i=1;i<=a;i++)
{
r=a%i;
if(a%i==0)
count++;
}
if(count==2)
System.out.println(r);
else
{}
}
}