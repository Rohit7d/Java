import java.util.*;
class A
{
int id;
String name;
void add()
{
Scanner s=new Scanner(System.in);
System.out.println("enter id="+"  "+"name=");
id=s.nextInt();
name=s.next();
}
}
class Demo
{
public static void main(String arg[])
{
A a=new A();
a.add();
System.out.print(a.id+" "+a.name);
}
}