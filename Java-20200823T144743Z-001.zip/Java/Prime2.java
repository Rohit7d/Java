import java.util.*;
class Prime2
{
public static void main(String arg[])
{
Scanner S=new Scanner(System.in);
int a;
System.out.print("ENTER NUM=");
int n=S.nextInt();
int count=0;
for(a=2;a<n;a++)
{
count=0;
for(int i=1;i<=a;i++)
{
if(a%i==0)
count++;
}
if(count==2)
System.out.println(a);
}
}
}