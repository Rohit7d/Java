//wap for this keyword
class Box
{
int l,b,h;
Box(int l,int b,int h)
{
this.l=l;
this.b=b;
this.h=h;
}
int volume()
{
return l*b*h;
}
}
class ThisKeyword
{
public static void main(String arg[]) 
{
                Box b1=new Box(7,8,9);
                Box b2=new Box(9,8,6);
                int v1=b1.volume();
                System.out.println(v1);
                int v2=b2.volume();
                System.out.println(v2);
              
}
}
