abstract class A
{
abstract void display();
abstract void show();
}
class B extends A
{
void display()
{
System.out.println("hi");
}

void show()
{
System.out.println("hello");
}
}
class Abstract
{
public static void main(String arg[])
{
B b=new B();
b.show();
b.display();
}
}