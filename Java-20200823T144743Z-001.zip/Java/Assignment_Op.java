class Assignment_Op
{
public static void main(String arg[])
{
int c=5;
c+=2;
System.out.println(c);

}
}
