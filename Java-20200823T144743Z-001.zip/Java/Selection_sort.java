class  Selection_sort
{
public static void main(String arg[])
{
int i,j,min,n,temp,a[];
Scanner s=new Scanner(System.in);
System.out.println("enter no of elements");
int n=s.nextInt();
System.out.println("enter elements");
for(i=0;i<n;i++)
int a[]=s.nextInt();
System.out.println("elements before sorting");
for(i=0;i<n;i++)
{
min=i;
for(j=i+1;j<n;j++)
{
if(a[j]<a[min])
{
min=j;
}
}
temp=a[i];
a[i]=a[min];
a[min]=temp;
}
for(i=0;i<n;i++)
System.out.println(a[i]);
}
}
