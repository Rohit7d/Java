class TypeConv
{
public static void main(String arg[])
{
byte b=12;
int c=135;
float f=123.67f;
float y=c;
int x=(int)f;
byte d=(byte)(12+126);
System.out.println(x);
System.out.println(d);
System.out.println(y);
}
}
