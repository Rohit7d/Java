class UnaryOp
{
public static void main(String arg[])
{
int a=10;
int b=7;
int c=--a;
System.out.println(c);
c=b--;
System.out.println(c);
System.out.println("a="+a);
System.out.println("b="+b);
System.out.println(~a);
System.out.println(~(~2));
System.out.println(!true);
System.out.println(a!=10);
}
}