class TempConv
{
public static void main(String arg[])
{
float c=42.56f;
float f=c*9/5+32;
System.out.println(c+"C="+f+"F");
}
}