class Test
{
public static void main(String arg[])
{
int a=5,b=6,c,d,e=10,f=7;
c=a+b;
d=e-f;
System.out.println("addition of "+a+"&"+b+"is"+c);
System.out.println(e+"-"+f+"="+d);
}
}