class Mprd
{
public static void main(String arg[])
{
int a[][]={{2,4},{2,7}};
int b[][]={{1,4},{6,7}};
int c[][]=new int[2][2];
{
for(int i=0;i<2;i++)
{
for(int j=0;j<2;j++)
{
c[i][j]=a[i][j]*b[i][j];
System.out.println(c[i][j]);
}
}
}
}
}