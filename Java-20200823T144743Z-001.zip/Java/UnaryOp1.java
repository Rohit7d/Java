class UnaryOp1
{
public static void main(String arg[])
{
int a=10;
int b=10;
System.out.println(a+++a++);
}
}