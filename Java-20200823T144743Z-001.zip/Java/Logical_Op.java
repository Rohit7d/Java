class Logical_Op
{
public static void main(String arg[])
{
System.out.println(true&false);
System.out.println(true|false);
System.out.println(true^true);
}
}

