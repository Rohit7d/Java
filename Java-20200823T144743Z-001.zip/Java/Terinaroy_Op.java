class Terinaroy_Op
{
public static void main(String arg[])
{
int c;
System.out.println(c=4>5?4:5);
System.out.println(c=4<5?4:5);
}
}
