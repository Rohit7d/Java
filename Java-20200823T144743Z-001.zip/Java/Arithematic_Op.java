class Arithematic_Op
{
public static void main(String arg[])
{
int a=56;
int b=7,c;
c=a+b;

System.out.println(c);
System.out.println(a+b);//expression can use in line also both have same value
c=a*b;
System.out.println(c);
System.out.println(a*b);
c=a/b;
System.out.println(c);
System.out.println(a/b);
c=a%b;
System.out.println(c);
System.out.println(a%b);
c=a-b;
System.out.println(c);
System.out.println(a-b);
}
}



