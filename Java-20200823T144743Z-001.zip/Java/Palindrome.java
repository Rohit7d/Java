class Palindrome
{
public static void main(String arg[])
{
int a=121,rem,rev=0;
int temp=a;
while(a>0)
{
rem=a%10;
rev=rev*10+rem;
a=a/10;
}
System.out.println("palindome is:"+rev);
}
}
