class DataTest
{
public static void main(String arg[])
{
int a=77;
byte b=123;
short s=12;
float f=123.56f;
long l=123456789;
double d=123456;
boolean x=true,y=false;
char c='k';
System.out.println("a value is "+a);
System.out.println("b value is "+b);
System.out.println("s value is "+s);
System.out.println("f value is "+f);
System.out.println("l value is "+l);
System.out.println("d value is "+d);
System.out.println("x value is "+x);
System.out.println("y value is "+y);
System.out.println("c value is "+c);
}
}
