class Bitwise_Op
{
public static void main(String arg[])
{
int a=4,b=3,c=6;
System.out.println(a&b);
System.out.println(a|b);
System.out.println(a^c);
}
}

