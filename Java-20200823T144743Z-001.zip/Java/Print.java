class Print
{
public static void main(String arg[])
{
System.out.println("hi how");
System.out.println("Are u dng");
System.out.print("?");
}
}
