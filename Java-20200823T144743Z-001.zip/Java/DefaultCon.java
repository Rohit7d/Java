// wap for default constructor
class Box
{
int l,b,h;
Box()
{
System.out.println("volume");
l=7;
b=8;
h=9;
}
int volume()
{
return l*b*h;
}
}
class DefaultCon
{
public static void main(String arg[]) 
{
	Box b1=new Box();
                Box b2=new Box();
                int v1=b1.volume();
               System.out.println(v1);
                int v2=b2.volume();
               System.out.println(v2);
              
}
}
