class Prime1
{
public static void main(String arg[])
{
int a;
int count=0;
for(a=2;a<50000;a++)
{
count=0;
for(int i=1;i<=a;i++)
{
if(a%i==0)
count++;
}
if(count==2)
System.out.println(a);
}
}
}