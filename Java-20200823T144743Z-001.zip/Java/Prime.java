class Prime
{
public static void main(String arg[])
{
int a=4,count=0;
for(int i=1;i<=a;i++)
{
if(a%i==0)
count++;
}
if(count==2)
System.out.println("prime");
else
System.out.println(" not prime");
}
}