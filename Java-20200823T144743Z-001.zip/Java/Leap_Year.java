class Leap_Year
{
public static void main(String arg[])
{
int a=2004;
int b=2002;
if(a%4==0)
{
if(a%100==0)
{
if(a%400==0)
System.out.println("a leap year");
else
System.out.println("not a leap year");
}
else
System.out.println("a leap year");
}
else
System.out.println("not a leap year");
}
}