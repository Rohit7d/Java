class Variable_Test
{
int a=10;
static int b=15;
public static void main(String arg[])
{
 int c=12;
System.out.println(c);
System.out.println(b);
}
}
 



