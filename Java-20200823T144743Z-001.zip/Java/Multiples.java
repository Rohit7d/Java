class Multiples//of 5
{
public static void main(String arg[])
{
for(int i=1235;i<=9854;i=i+5)
System.out.println(i);
}
}