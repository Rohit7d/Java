class Display
{
public static void main(String arg[])
{
System.out.println("jbrec");
System.out.print("cllg");
}
}