//prgrm for Garbage collector
class Test
{
protected void finalize()
{
System.out.println("object delete");
}
}
class GCDemo
{
public static void main(String ar[])
{
Test t1=new Test();
new Test();
t1=null;
System.gc();

}
}

