//reusbility of object
class O
{
int x;
void display()
{
System.out.println(x);
}
}
class Obj
{
public static void main(String arg[])
{
O t1=new O();
O t2;
t1.x=5;
t1.display();
t2=t1;
t2.x=25;
t2.display();

}
}


