class Shift_Op
{
public static void main(String arg[])
{
System.out.println(4>>1);
System.out.println(4>>3);
System.out.println(4<<1);
System.out.println(4<<3);
System.out.println(8>>>3);
System.out.println(-8>>>3);
}
}
