class UnaryOp2
{
public static void main(String arg[])
{
int a=10;

System.out.println(a++ + ++a);
}
}