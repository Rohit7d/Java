class Cmnd
{
public static void main(String arg[])
{
System.out.println(arg.length);
}

}